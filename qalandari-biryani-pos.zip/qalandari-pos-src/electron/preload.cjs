const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  login: (creds) => ipcRenderer.invoke('auth:login', creds),
  changeCredentials: (data) => ipcRenderer.invoke('auth:changeCredentials', data),

  getMenu: () => ipcRenderer.invoke('menu:getAll'),
  getMenuAdmin: () => ipcRenderer.invoke('menu:getAllAdmin'),
  upsertMenuItem: (item) => ipcRenderer.invoke('menu:upsert', item),
  deleteMenuItem: (id) => ipcRenderer.invoke('menu:delete', id),

  createOrder: (order) => ipcRenderer.invoke('orders:create', order),
  getTodayOrders: () => ipcRenderer.invoke('orders:getToday'),
  getOrdersByDate: (date) => ipcRenderer.invoke('orders:getByDate', date),
  getOrderById: (id) => ipcRenderer.invoke('orders:getById', id),
  searchOrders: (q) => ipcRenderer.invoke('orders:search', q),
  getTodayStats: () => ipcRenderer.invoke('orders:statsToday'),
  exportCsv: (date) => ipcRenderer.invoke('orders:exportCsv', date),

  printReceipt: (html) => ipcRenderer.invoke('print:receipt', html),

  backupDb: () => ipcRenderer.invoke('backup:create'),
  restoreDb: () => ipcRenderer.invoke('backup:restore'),

  getVersion: () => ipcRenderer.invoke('app:getVersion')
});
