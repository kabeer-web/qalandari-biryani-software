import Database from 'better-sqlite3';
import path from 'path';
import { app } from 'electron';
import fs from 'fs';
import bcrypt from 'bcryptjs';

let db = null;

export function getDbPath() {
  const userData = app.getPath('userData');
  return path.join(userData, 'qalandari-pos.db');
}

export function initDatabase() {
  const dbPath = getDbPath();
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS menu_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price REAL NOT NULL,
      category TEXT NOT NULL,
      size TEXT,
      enabled INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_number TEXT UNIQUE NOT NULL,
      order_type TEXT NOT NULL,
      customer_name TEXT,
      customer_phone TEXT,
      subtotal REAL NOT NULL,
      discount REAL DEFAULT 0,
      total REAL NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      menu_item_id INTEGER,
      name TEXT NOT NULL,
      price REAL NOT NULL,
      quantity INTEGER NOT NULL,
      line_total REAL NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
  `);

  // Default admin: admin / admin123
  const existing = db.prepare('SELECT value FROM settings WHERE key = ?').get('admin_user');
  if (!existing) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('admin_user', 'admin');
    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('admin_pass_hash', hash);
  }

  // Seed menu if empty
  const count = db.prepare('SELECT COUNT(*) as c FROM menu_items').get().c;
  if (count === 0) {
    const seed = [
      ['Chicken Biryani', 200, 'Biryani', null],
      ['Beef Biryani', 300, 'Biryani', null],
      ['Chicken Pulao', 250, 'Pulao', null],
      ['Beef Pulao', 300, 'Pulao', null],
      ['Coke', 80, 'Drinks', 'Regular'],
      ['Coke', 120, 'Drinks', 'Large'],
      ['Pepsi', 80, 'Drinks', 'Regular'],
      ['Pepsi', 120, 'Drinks', 'Large'],
      ['Sprite', 80, 'Drinks', 'Regular'],
      ['Sprite', 120, 'Drinks', 'Large'],
      ['7UP', 80, 'Drinks', 'Regular'],
      ['7UP', 120, 'Drinks', 'Large'],
      ['Water', 50, 'Drinks', 'Bottle']
    ];
    const stmt = db.prepare(
      'INSERT INTO menu_items (name, price, category, size, enabled) VALUES (?,?,?,?,1)'
    );
    for (const row of seed) stmt.run(...row);
  }
}

export function getDb() {
  if (!db) initDatabase();
  return db;
}

export function backupDatabase(destPath) {
  const src = getDbPath();
  fs.copyFileSync(src, destPath);
}

export function restoreDatabase(srcPath) {
  if (db) {
    db.close();
    db = null;
  }
  const dest = getDbPath();
  fs.copyFileSync(srcPath, dest);
  initDatabase();
}
