import { app, BrowserWindow, ipcMain, dialog } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { initDatabase, getDb, backupDatabase, restoreDatabase } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isDev = process.env.NODE_ENV === 'development';
let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 1024,
    minHeight: 700,
    backgroundColor: '#1c1917',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    },
    show: false,
    title: 'Qalandari Biryani POS'
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  initDatabase();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ---------- Auth ----------
ipcMain.handle('auth:login', async (_, { username, password }) => {
  try {
    const db = getDb();
    const user = db.prepare('SELECT value FROM settings WHERE key = ?').get('admin_user');
    const hash = db.prepare('SELECT value FROM settings WHERE key = ?').get('admin_pass_hash');
    if (!user || !hash) return { success: false, message: 'Admin not configured' };
    const match = bcrypt.compareSync(password, hash.value);
    if (user.value === username && match) return { success: true };
    return { success: false, message: 'Invalid username or password' };
  } catch (e) {
    return { success: false, message: e.message };
  }
});

ipcMain.handle('auth:changeCredentials', async (_, { currentPass, newUser, newPass }) => {
  try {
    const db = getDb();
    const hashRow = db.prepare('SELECT value FROM settings WHERE key = ?').get('admin_pass_hash');
    if (!bcrypt.compareSync(currentPass, hashRow.value)) {
      return { success: false, message: 'Current password incorrect' };
    }
    if (!newUser || newUser.length < 3) {
      return { success: false, message: 'Username must be at least 3 characters' };
    }
    if (!newPass || newPass.length < 4) {
      return { success: false, message: 'Password must be at least 4 characters' };
    }
    const newHash = bcrypt.hashSync(newPass, 10);
    db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(newUser, 'admin_user');
    db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(newHash, 'admin_pass_hash');
    return { success: true };
  } catch (e) {
    return { success: false, message: e.message };
  }
});

// ---------- Menu ----------
ipcMain.handle('menu:getAll', () => {
  const db = getDb();
  return db.prepare('SELECT * FROM menu_items WHERE enabled = 1 ORDER BY category, name, size').all();
});

ipcMain.handle('menu:getAllAdmin', () => {
  const db = getDb();
  return db.prepare('SELECT * FROM menu_items ORDER BY category, name, size').all();
});

ipcMain.handle('menu:upsert', (_, item) => {
  const db = getDb();
  if (item.id) {
    db.prepare(
      `UPDATE menu_items SET name=?, price=?, category=?, size=?, enabled=? WHERE id=?`
    ).run(item.name, item.price, item.category, item.size || null, item.enabled ? 1 : 0, item.id);
    return { success: true, id: item.id };
  } else {
    const r = db
      .prepare(
        `INSERT INTO menu_items (name, price, category, size, enabled) VALUES (?,?,?,?,?)`
      )
      .run(item.name, item.price, item.category, item.size || null, item.enabled !== false ? 1 : 0);
    return { success: true, id: Number(r.lastInsertRowid) };
  }
});

ipcMain.handle('menu:delete', (_, id) => {
  const db = getDb();
  db.prepare('DELETE FROM menu_items WHERE id = ?').run(id);
  return { success: true };
});

// ---------- Orders ----------
ipcMain.handle('orders:create', (_, order) => {
  const db = getDb();
  const tx = db.transaction(() => {
    const billNo = `QB-${Date.now().toString().slice(-8)}`;
    const result = db
      .prepare(
        `INSERT INTO orders (bill_number, order_type, customer_name, customer_phone, subtotal, discount, total, created_at)
         VALUES (?,?,?,?,?,?,?,datetime('now','localtime'))`
      )
      .run(
        billNo,
        order.orderType,
        order.customerName || null,
        order.customerPhone || null,
        order.subtotal,
        order.discount || 0,
        order.total
      );
    const orderId = Number(result.lastInsertRowid);

    const insertItem = db.prepare(
      `INSERT INTO order_items (order_id, menu_item_id, name, price, quantity, line_total)
       VALUES (?,?,?,?,?,?)`
    );
    for (const it of order.items) {
      insertItem.run(orderId, it.id || null, it.name, it.price, it.qty, it.price * it.qty);
    }
    return { orderId, billNumber: billNo };
  });
  return tx();
});

ipcMain.handle('orders:getToday', () => {
  const db = getDb();
  return db
    .prepare(
      `SELECT * FROM orders WHERE date(created_at) = date('now','localtime') ORDER BY created_at DESC`
    )
    .all();
});

ipcMain.handle('orders:getByDate', (_, date) => {
  const db = getDb();
  return db
    .prepare(`SELECT * FROM orders WHERE date(created_at) = ? ORDER BY created_at DESC`)
    .all(date);
});

ipcMain.handle('orders:getById', (_, id) => {
  const db = getDb();
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
  if (!order) return null;
  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(id);
  return { ...order, items };
});

ipcMain.handle('orders:search', (_, q) => {
  const db = getDb();
  return db
    .prepare(
      `SELECT * FROM orders
       WHERE bill_number LIKE ? OR customer_name LIKE ?
       ORDER BY created_at DESC LIMIT 100`
    )
    .all(`%${q}%`, `%${q}%`);
});

ipcMain.handle('orders:statsToday', () => {
  const db = getDb();
  return db
    .prepare(
      `SELECT
         COUNT(*) as orderCount,
         COALESCE(SUM(total),0) as totalSales,
         (SELECT COALESCE(SUM(quantity),0) FROM order_items oi
          JOIN orders o ON o.id = oi.order_id
          WHERE date(o.created_at) = date('now','localtime')) as itemsSold
       FROM orders WHERE date(created_at) = date('now','localtime')`
    )
    .get();
});

ipcMain.handle('orders:exportCsv', async (_, date) => {
  const db = getDb();
  const targetDate = date || new Date().toISOString().slice(0, 10);
  const orders = db
    .prepare(
      `SELECT o.*, GROUP_CONCAT(oi.name || ' x' || oi.quantity, '; ') as items
       FROM orders o
       LEFT JOIN order_items oi ON oi.order_id = o.id
       WHERE date(o.created_at) = ?
       GROUP BY o.id
       ORDER BY o.created_at`
    )
    .all(targetDate);

  const header = 'Bill Number,Date,Type,Customer,Phone,Subtotal,Discount,Total,Items\n';
  const rows = orders
    .map(
      (o) =>
        `"${o.bill_number}","${o.created_at}","${o.order_type}","${o.customer_name || ''}","${o.customer_phone || ''}",${o.subtotal},${o.discount},${o.total},"${(o.items || '').replace(/"/g, '""')}"`
    )
    .join('\n');
  const csv = header + rows;

  const { filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'Export Daily Sales',
    defaultPath: `Qalandari-Sales-${targetDate}.csv`,
    filters: [{ name: 'CSV', extensions: ['csv'] }]
  });
  if (filePath) {
    fs.writeFileSync(filePath, csv, 'utf8');
    return { success: true, path: filePath };
  }
  return { success: false };
});

// ---------- Print ----------
ipcMain.handle('print:receipt', async (_, html) => {
  return new Promise((resolve) => {
    const win = new BrowserWindow({
      width: 320,
      height: 600,
      show: false,
      webPreferences: { offscreen: true }
    });
    win
      .loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`)
      .then(() => {
        win.webContents.print({ silent: false, printBackground: true }, (success, failureReason) => {
          win.close();
          if (success) resolve({ success: true });
          else resolve({ success: false, message: failureReason || 'Print cancelled or failed' });
        });
      })
      .catch((e) => {
        win.close();
        resolve({ success: false, message: e.message });
      });
  });
});

// ---------- Backup ----------
ipcMain.handle('backup:create', async () => {
  const { filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'Backup Database',
    defaultPath: `qalandari-backup-${new Date().toISOString().slice(0, 10)}.db`,
    filters: [{ name: 'SQLite DB', extensions: ['db'] }]
  });
  if (!filePath) return { success: false };
  try {
    backupDatabase(filePath);
    return { success: true, path: filePath };
  } catch (e) {
    return { success: false, message: e.message };
  }
});

ipcMain.handle('backup:restore', async () => {
  const { filePaths } = await dialog.showOpenDialog(mainWindow, {
    title: 'Restore Database',
    filters: [{ name: 'SQLite DB', extensions: ['db'] }],
    properties: ['openFile']
  });
  if (!filePaths?.[0]) return { success: false };
  const confirm = await dialog.showMessageBox(mainWindow, {
    type: 'warning',
    buttons: ['Cancel', 'Restore'],
    defaultId: 0,
    cancelId: 0,
    title: 'Confirm Restore',
    message: 'This will replace ALL current orders, menu and settings. Continue?'
  });
  if (confirm.response !== 1) return { success: false };
  try {
    restoreDatabase(filePaths[0]);
    return { success: true };
  } catch (e) {
    return { success: false, message: e.message };
  }
});

ipcMain.handle('app:getVersion', () => app.getVersion());
