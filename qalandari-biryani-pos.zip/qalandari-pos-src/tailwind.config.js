/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        orange: {
          DEFAULT: '#e85d04',
          50: '#fff7ed',
          100: '#ffedd5',
          200: '#fed7aa',
          400: '#fb923c',
          500: '#e85d04',
          600: '#c2410c',
          700: '#9a3412'
        },
        cream: '#fff8f0',
        charcoal: {
          DEFAULT: '#1c1917',
          900: '#0c0a09',
          800: '#1c1917',
          700: '#292524',
          600: '#44403c',
          500: '#57534e',
          400: '#78716c',
          300: '#a8a29e'
        },
        green: {
          DEFAULT: '#2d6a4f',
          600: '#1b4332',
          500: '#2d6a4f',
          400: '#40916c'
        }
      },
      fontFamily: {
        sans: ['Segoe UI', 'system-ui', '-apple-system', 'sans-serif']
      }
    }
  },
  plugins: []
};
