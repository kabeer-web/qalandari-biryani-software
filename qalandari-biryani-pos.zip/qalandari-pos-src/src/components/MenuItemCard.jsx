import React from 'react';
import { formatPKR } from '../utils/format';

export default function MenuItemCard({ item, onAdd }) {
  return (
    <button
      onClick={() => onAdd(item)}
      className="group bg-charcoal-700 hover:bg-charcoal-600 border border-charcoal-600 hover:border-orange-500/50 rounded-xl p-4 text-left transition-all active:scale-[0.98] shadow-sm hover:shadow-md"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="font-semibold text-cream text-sm leading-snug truncate group-hover:text-orange-300 transition-colors">
            {item.name}
          </div>
          {item.size && (
            <div className="text-xs text-charcoal-400 mt-0.5">{item.size}</div>
          )}
        </div>
        <div className="flex-shrink-0 text-orange-400 font-bold text-sm whitespace-nowrap">
          {formatPKR(item.price)}
        </div>
      </div>
      <div className="mt-2 text-[10px] uppercase tracking-wider text-charcoal-400 font-medium">
        {item.category}
      </div>
    </button>
  );
}
