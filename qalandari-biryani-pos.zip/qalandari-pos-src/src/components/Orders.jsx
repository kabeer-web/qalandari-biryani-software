import React, { useState, useEffect, useCallback } from 'react';
import { formatPKR, formatDateTime, todayISO } from '../utils/format';
import { buildReceiptHtml } from '../utils/receipt';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [stats, setStats] = useState({ orderCount: 0, totalSales: 0, itemsSold: 0 });
  const [date, setDate] = useState(todayISO());
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      let list;
      if (search.trim()) {
        list = await window.api.searchOrders(search.trim());
      } else {
        list = await window.api.getOrdersByDate(date);
      }
      setOrders(list || []);
      if (!search.trim() && date === todayISO()) {
        const s = await window.api.getTodayStats();
        setStats(s || { orderCount: 0, totalSales: 0, itemsSold: 0 });
      }
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  }, [date, search]);

  useEffect(() => {
    load();
  }, [load]);

  const openOrder = async (id) => {
    try {
      const full = await window.api.getOrderById(id);
      setSelected(full);
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    }
  };

  const handleReprint = async () => {
    if (!selected) return;
    setLoading(true);
    try {
      const html = buildReceiptHtml(selected);
      const res = await window.api.printReceipt(html);
      if (res.success) setMessage({ type: 'success', text: 'Reprint sent to printer' });
      else setMessage({ type: 'error', text: res.message || 'Print failed' });
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    setLoading(true);
    try {
      const res = await window.api.exportCsv(date);
      if (res.success) setMessage({ type: 'success', text: `Exported to ${res.path}` });
      else setMessage({ type: 'error', text: 'Export cancelled' });
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-full overflow-hidden">
      {/* List */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Stats bar */}
        {date === todayISO() && !search && (
          <div className="grid grid-cols-3 gap-3 p-4 border-b border-charcoal-600">
            <div className="bg-charcoal-700 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-orange-400">{stats.orderCount}</div>
              <div className="text-xs text-charcoal-400 mt-1">Orders Today</div>
            </div>
            <div className="bg-charcoal-700 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-green-400">{formatPKR(stats.totalSales)}</div>
              <div className="text-xs text-charcoal-400 mt-1">Total Sales</div>
            </div>
            <div className="bg-charcoal-700 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-cream">{stats.itemsSold}</div>
              <div className="text-xs text-charcoal-400 mt-1">Items Sold</div>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-charcoal-600">
          <input
            type="date"
            value={date}
            onChange={(e) => {
              setDate(e.target.value);
              setSearch('');
            }}
            className="px-3 py-1.5 rounded-lg bg-charcoal-700 border border-charcoal-600 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
          />
          <input
            type="text"
            placeholder="Search bill # or customer…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 px-3 py-1.5 rounded-lg bg-charcoal-700 border border-charcoal-600 text-sm text-white placeholder-charcoal-400 focus:outline-none focus:ring-1 focus:ring-orange-500"
          />
          <button
            onClick={load}
            className="px-3 py-1.5 rounded-lg bg-charcoal-600 hover:bg-charcoal-500 text-sm text-white"
          >
            Refresh
          </button>
          <button
            onClick={handleExport}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg bg-green-600 hover:bg-green-500 text-sm text-white font-medium"
          >
            Export CSV
          </button>
        </div>

        {message && (
          <div
            className={`mx-4 mt-3 text-xs px-3 py-2 rounded-lg ${
              message.type === 'success'
                ? 'bg-green-900/40 text-green-300 border border-green-700'
                : 'bg-red-900/40 text-red-200 border border-red-700'
            }`}
          >
            {message.text}
          </div>
        )}

        {/* Table */}
        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-charcoal-800 text-charcoal-400 text-xs uppercase">
              <tr>
                <th className="text-left px-4 py-2.5 font-medium">Bill #</th>
                <th className="text-left px-4 py-2.5 font-medium">Time</th>
                <th className="text-left px-4 py-2.5 font-medium">Type</th>
                <th className="text-left px-4 py-2.5 font-medium">Customer</th>
                <th className="text-right px-4 py-2.5 font-medium">Total</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr
                  key={o.id}
                  onClick={() => openOrder(o.id)}
                  className={`border-t border-charcoal-700 cursor-pointer hover:bg-charcoal-700/60 transition-colors ${
                    selected?.id === o.id ? 'bg-orange-500/10' : ''
                  }`}
                >
                  <td className="px-4 py-2.5 font-medium text-orange-400">{o.bill_number}</td>
                  <td className="px-4 py-2.5 text-charcoal-300">{formatDateTime(o.created_at)}</td>
                  <td className="px-4 py-2.5 text-charcoal-300">{o.order_type}</td>
                  <td className="px-4 py-2.5 text-charcoal-300">{o.customer_name || '—'}</td>
                  <td className="px-4 py-2.5 text-right font-semibold text-cream">
                    {formatPKR(o.total)}
                  </td>
                </tr>
              ))}
              {orders.length === 0 && !loading && (
                <tr>
                  <td colSpan={5} className="text-center text-charcoal-400 py-12">
                    No orders found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail panel */}
      {selected && (
        <div className="w-80 flex-shrink-0 bg-charcoal-800 border-l border-charcoal-600 flex flex-col">
          <div className="px-4 py-3 border-b border-charcoal-600 flex items-center justify-between">
            <h3 className="font-semibold text-cream">Bill Details</h3>
            <button
              onClick={() => setSelected(null)}
              className="text-charcoal-400 hover:text-white text-sm"
            >
              ✕
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3 text-sm">
            <div>
              <span className="text-charcoal-400">Bill #</span>
              <div className="font-semibold text-orange-400">{selected.bill_number}</div>
            </div>
            <div>
              <span className="text-charcoal-400">Date</span>
              <div className="text-cream">{formatDateTime(selected.created_at)}</div>
            </div>
            <div>
              <span className="text-charcoal-400">Type</span>
              <div className="text-cream">{selected.order_type}</div>
            </div>
            {selected.customer_name && (
              <div>
                <span className="text-charcoal-400">Customer</span>
                <div className="text-cream">{selected.customer_name}</div>
              </div>
            )}
            {selected.customer_phone && (
              <div>
                <span className="text-charcoal-400">Phone</span>
                <div className="text-cream">{selected.customer_phone}</div>
              </div>
            )}
            <div className="border-t border-charcoal-600 pt-3 space-y-1.5">
              {(selected.items || []).map((it, i) => (
                <div key={i} className="flex justify-between">
                  <span className="text-charcoal-300">
                    {it.name} × {it.quantity}
                  </span>
                  <span className="text-cream">{formatPKR(it.line_total)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-charcoal-600 pt-3 space-y-1">
              <div className="flex justify-between text-charcoal-300">
                <span>Subtotal</span>
                <span>{formatPKR(selected.subtotal)}</span>
              </div>
              {selected.discount > 0 && (
                <div className="flex justify-between text-charcoal-300">
                  <span>Discount</span>
                  <span>- {formatPKR(selected.discount)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg text-cream">
                <span>Total</span>
                <span className="text-orange-400">{formatPKR(selected.total)}</span>
              </div>
            </div>
          </div>
          <div className="p-4 border-t border-charcoal-600">
            <button
              onClick={handleReprint}
              disabled={loading}
              className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold text-sm disabled:opacity-50"
            >
              Reprint Receipt
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
