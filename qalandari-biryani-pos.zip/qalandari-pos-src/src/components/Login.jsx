import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login, loading, error, setError } = useAuth();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    await login(username.trim(), password);
  };

  return (
    <div className="h-screen w-screen flex items-center justify-center bg-gradient-to-br from-charcoal-900 via-charcoal-800 to-charcoal-700">
      <div className="w-full max-w-md mx-4">
        <div className="bg-charcoal-700 rounded-2xl shadow-2xl border border-charcoal-600 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-orange-600 to-orange-500 px-8 py-6 text-center">
            <div className="text-3xl font-bold text-white tracking-tight">Qalandari Biryani</div>
            <div className="text-orange-100 text-sm mt-1">Food Center · POS System</div>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-5">
            <div>
              <label className="block text-sm font-medium text-charcoal-300 mb-1.5">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white placeholder-charcoal-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                placeholder="admin"
                autoFocus
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-charcoal-300 mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white placeholder-charcoal-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                placeholder="••••••••"
                required
              />
            </div>

            {error && (
              <div className="bg-red-900/40 border border-red-700 text-red-200 text-sm px-4 py-2.5 rounded-lg">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-lg bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white font-semibold text-base transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>

          <div className="px-8 pb-6 text-center">
            <p className="text-xs text-charcoal-400">
              Default: <span className="text-charcoal-300">admin</span> / <span className="text-charcoal-300">admin123</span>
            </p>
            <p className="text-[10px] text-charcoal-500 mt-2">Powered by BeerFlow Technologies</p>
          </div>
        </div>
      </div>
    </div>
  );
}
