import React, { useState, useEffect, useCallback } from 'react';
import { formatPKR } from '../utils/format';

export default function Settings() {
  const [menu, setMenu] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: '', price: '', category: 'Biryani', size: '', enabled: true });
  const [credForm, setCredForm] = useState({ currentPass: '', newUser: '', newPass: '', confirmPass: '' });
  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState('menu');

  const loadMenu = useCallback(async () => {
    try {
      const items = await window.api.getMenuAdmin();
      setMenu(items || []);
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    }
  }, []);

  useEffect(() => {
    loadMenu();
  }, [loadMenu]);

  const startEdit = (item) => {
    setEditing(item.id);
    setForm({
      name: item.name,
      price: String(item.price),
      category: item.category,
      size: item.size || '',
      enabled: !!item.enabled
    });
  };

  const startAdd = () => {
    setEditing('new');
    setForm({ name: '', price: '', category: 'Biryani', size: '', enabled: true });
  };

  const cancelEdit = () => {
    setEditing(null);
    setForm({ name: '', price: '', category: 'Biryani', size: '', enabled: true });
  };

  const saveItem = async () => {
    if (!form.name.trim() || !form.price || Number(form.price) < 0) {
      setMessage({ type: 'error', text: 'Name and valid price required' });
      return;
    }
    setLoading(true);
    try {
      const payload = {
        id: editing === 'new' ? null : editing,
        name: form.name.trim(),
        price: Number(form.price),
        category: form.category,
        size: form.size.trim() || null,
        enabled: form.enabled
      };
      await window.api.upsertMenuItem(payload);
      setMessage({ type: 'success', text: 'Menu item saved' });
      cancelEdit();
      await loadMenu();
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  const deleteItem = async (id) => {
    if (!confirm('Delete this menu item?')) return;
    setLoading(true);
    try {
      await window.api.deleteMenuItem(id);
      setMessage({ type: 'success', text: 'Item deleted' });
      await loadMenu();
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  const changeCredentials = async () => {
    if (credForm.newPass !== credForm.confirmPass) {
      setMessage({ type: 'error', text: 'New passwords do not match' });
      return;
    }
    setLoading(true);
    try {
      const res = await window.api.changeCredentials({
        currentPass: credForm.currentPass,
        newUser: credForm.newUser.trim(),
        newPass: credForm.newPass
      });
      if (res.success) {
        setMessage({ type: 'success', text: 'Credentials updated. Use new login next time.' });
        setCredForm({ currentPass: '', newUser: '', newPass: '', confirmPass: '' });
      } else {
        setMessage({ type: 'error', text: res.message });
      }
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  const handleBackup = async () => {
    setLoading(true);
    try {
      const res = await window.api.backupDb();
      if (res.success) setMessage({ type: 'success', text: `Backup saved: ${res.path}` });
      else setMessage({ type: 'error', text: res.message || 'Backup cancelled' });
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  const handleRestore = async () => {
    setLoading(true);
    try {
      const res = await window.api.restoreDb();
      if (res.success) {
        setMessage({ type: 'success', text: 'Database restored. Restart recommended.' });
        await loadMenu();
      } else {
        setMessage({ type: 'error', text: res.message || 'Restore cancelled' });
      }
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-5">
      <h1 className="text-xl font-bold text-cream mb-4">Settings</h1>

      {/* Tabs */}
      <div className="flex gap-2 mb-5">
        {[
          { id: 'menu', label: 'Menu Items' },
          { id: 'account', label: 'Account' },
          { id: 'data', label: 'Backup & Data' }
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              tab === t.id
                ? 'bg-orange-500 text-white'
                : 'bg-charcoal-700 text-charcoal-300 hover:bg-charcoal-600'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {message && (
        <div
          className={`mb-4 text-sm px-4 py-2.5 rounded-lg ${
            message.type === 'success'
              ? 'bg-green-900/40 text-green-300 border border-green-700'
              : 'bg-red-900/40 text-red-200 border border-red-700'
          }`}
        >
          {message.text}
        </div>
      )}

      {/* Menu tab */}
      {tab === 'menu' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-cream">Menu Items</h2>
            <button
              onClick={startAdd}
              className="px-4 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium"
            >
              + Add Item
            </button>
          </div>

          {editing && (
            <div className="bg-charcoal-700 rounded-xl p-4 mb-4 border border-charcoal-600 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-charcoal-400">Name</label>
                  <input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full mt-1 px-3 py-1.5 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-charcoal-400">Price (Rs.)</label>
                  <input
                    type="number"
                    min="0"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                    className="w-full mt-1 px-3 py-1.5 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-charcoal-400">Category</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full mt-1 px-3 py-1.5 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                  >
                    <option>Biryani</option>
                    <option>Pulao</option>
                    <option>Drinks</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-charcoal-400">Size (optional)</label>
                  <input
                    value={form.size}
                    onChange={(e) => setForm({ ...form, size: e.target.value })}
                    placeholder="Regular / Large"
                    className="w-full mt-1 px-3 py-1.5 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              </div>
              <label className="flex items-center gap-2 text-sm text-charcoal-300">
                <input
                  type="checkbox"
                  checked={form.enabled}
                  onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                  className="rounded"
                />
                Enabled (visible on POS)
              </label>
              <div className="flex gap-2">
                <button
                  onClick={saveItem}
                  disabled={loading}
                  className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 text-white text-sm font-medium disabled:opacity-50"
                >
                  Save
                </button>
                <button
                  onClick={cancelEdit}
                  className="px-4 py-2 rounded-lg bg-charcoal-600 hover:bg-charcoal-500 text-white text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="bg-charcoal-700 rounded-xl overflow-hidden border border-charcoal-600">
            <table className="w-full text-sm">
              <thead className="bg-charcoal-800 text-charcoal-400 text-xs uppercase">
                <tr>
                  <th className="text-left px-4 py-2.5">Name</th>
                  <th className="text-left px-4 py-2.5">Category</th>
                  <th className="text-left px-4 py-2.5">Size</th>
                  <th className="text-right px-4 py-2.5">Price</th>
                  <th className="text-center px-4 py-2.5">Status</th>
                  <th className="text-right px-4 py-2.5">Actions</th>
                </tr>
              </thead>
              <tbody>
                {menu.map((item) => (
                  <tr key={item.id} className="border-t border-charcoal-600">
                    <td className="px-4 py-2.5 text-cream font-medium">{item.name}</td>
                    <td className="px-4 py-2.5 text-charcoal-300">{item.category}</td>
                    <td className="px-4 py-2.5 text-charcoal-300">{item.size || '—'}</td>
                    <td className="px-4 py-2.5 text-right text-orange-400 font-semibold">
                      {formatPKR(item.price)}
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full ${
                          item.enabled
                            ? 'bg-green-900/50 text-green-300'
                            : 'bg-charcoal-600 text-charcoal-400'
                        }`}
                      >
                        {item.enabled ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right space-x-2">
                      <button
                        onClick={() => startEdit(item)}
                        className="text-orange-400 hover:text-orange-300 text-xs font-medium"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => deleteItem(item.id)}
                        className="text-red-400 hover:text-red-300 text-xs font-medium"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Account tab */}
      {tab === 'account' && (
        <div className="max-w-md">
          <h2 className="font-semibold text-cream mb-4">Change Login Credentials</h2>
          <div className="bg-charcoal-700 rounded-xl p-5 border border-charcoal-600 space-y-4">
            <div>
              <label className="text-xs text-charcoal-400">Current Password</label>
              <input
                type="password"
                value={credForm.currentPass}
                onChange={(e) => setCredForm({ ...credForm, currentPass: e.target.value })}
                className="w-full mt-1 px-3 py-2 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
            <div>
              <label className="text-xs text-charcoal-400">New Username</label>
              <input
                type="text"
                value={credForm.newUser}
                onChange={(e) => setCredForm({ ...credForm, newUser: e.target.value })}
                className="w-full mt-1 px-3 py-2 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
            <div>
              <label className="text-xs text-charcoal-400">New Password</label>
              <input
                type="password"
                value={credForm.newPass}
                onChange={(e) => setCredForm({ ...credForm, newPass: e.target.value })}
                className="w-full mt-1 px-3 py-2 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
            <div>
              <label className="text-xs text-charcoal-400">Confirm New Password</label>
              <input
                type="password"
                value={credForm.confirmPass}
                onChange={(e) => setCredForm({ ...credForm, confirmPass: e.target.value })}
                className="w-full mt-1 px-3 py-2 rounded-lg bg-charcoal-800 border border-charcoal-600 text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
            </div>
            <button
              onClick={changeCredentials}
              disabled={loading}
              className="w-full py-2.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-semibold text-sm disabled:opacity-50"
            >
              Update Credentials
            </button>
          </div>
        </div>
      )}

      {/* Data tab */}
      {tab === 'data' && (
        <div className="max-w-md space-y-4">
          <h2 className="font-semibold text-cream mb-2">Database Backup & Restore</h2>
          <p className="text-sm text-charcoal-400">
            All data is stored locally on this computer. Backup regularly to avoid data loss.
          </p>
          <div className="flex gap-3">
            <button
              onClick={handleBackup}
              disabled={loading}
              className="flex-1 py-3 rounded-xl bg-green-600 hover:bg-green-500 text-white font-semibold text-sm disabled:opacity-50"
            >
              Create Backup
            </button>
            <button
              onClick={handleRestore}
              disabled={loading}
              className="flex-1 py-3 rounded-xl bg-red-700 hover:bg-red-600 text-white font-semibold text-sm disabled:opacity-50"
            >
              Restore Backup
            </button>
          </div>
          <div className="bg-charcoal-700 rounded-xl p-4 border border-charcoal-600 text-xs text-charcoal-400">
            <p className="font-medium text-charcoal-300 mb-1">Notes</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Backup creates a copy of the SQLite database file.</li>
              <li>Restore replaces all current data. A confirmation is required.</li>
              <li>Uninstalling the app does not automatically delete order records stored in user data.</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
