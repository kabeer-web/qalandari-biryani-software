import React, { useState, useEffect, useCallback } from 'react';
import MenuItemCard from './MenuItemCard';
import { formatPKR } from '../utils/format';
import { buildReceiptHtml } from '../utils/receipt';

export default function POS() {
  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState([]);
  const [orderType, setOrderType] = useState('Takeaway');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [discount, setDiscount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [lastOrder, setLastOrder] = useState(null);

  const loadMenu = useCallback(async () => {
    try {
      const items = await window.api.getMenu();
      setMenu(items || []);
    } catch (e) {
      setMessage({ type: 'error', text: 'Failed to load menu' });
    }
  }, []);

  useEffect(() => {
    loadMenu();
  }, [loadMenu]);

  const addToCart = (item) => {
    setCart((prev) => {
      const key = `${item.id}-${item.size || ''}`;
      const existing = prev.find((c) => `${c.id}-${c.size || ''}` === key);
      if (existing) {
        return prev.map((c) =>
          `${c.id}-${c.size || ''}` === key ? { ...c, qty: c.qty + 1 } : c
        );
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const updateQty = (key, delta) => {
    setCart((prev) =>
      prev
        .map((c) => {
          if (`${c.id}-${c.size || ''}` !== key) return c;
          const qty = c.qty + delta;
          return qty <= 0 ? null : { ...c, qty };
        })
        .filter(Boolean)
    );
  };

  const removeItem = (key) => {
    setCart((prev) => prev.filter((c) => `${c.id}-${c.size || ''}` !== key));
  };

  const subtotal = cart.reduce((s, c) => s + c.price * c.qty, 0);
  const discountVal = Math.min(Math.max(0, Number(discount) || 0), subtotal);
  const total = subtotal - discountVal;

  const clearCart = () => {
    setCart([]);
    setCustomerName('');
    setCustomerPhone('');
    setDiscount(0);
    setMessage(null);
  };

  const handleGenerateBill = async () => {
    if (cart.length === 0) {
      setMessage({ type: 'error', text: 'Cart is empty' });
      return;
    }
    setLoading(true);
    setMessage(null);
    try {
      const orderPayload = {
        orderType,
        customerName: customerName.trim() || null,
        customerPhone: customerPhone.trim() || null,
        items: cart.map((c) => ({
          id: c.id,
          name: c.size ? `${c.name} (${c.size})` : c.name,
          price: c.price,
          qty: c.qty
        })),
        subtotal,
        discount: discountVal,
        total
      };

      const result = await window.api.createOrder(orderPayload);
      const fullOrder = {
        ...orderPayload,
        billNumber: result.billNumber,
        bill_number: result.billNumber,
        order_type: orderType,
        customer_name: customerName,
        customer_phone: customerPhone,
        created_at: new Date().toISOString(),
        items: orderPayload.items.map((it) => ({
          ...it,
          quantity: it.qty,
          line_total: it.price * it.qty
        }))
      };
      setLastOrder(fullOrder);

      const html = buildReceiptHtml(fullOrder);
      const printRes = await window.api.printReceipt(html);

      if (printRes.success) {
        setMessage({ type: 'success', text: `Bill ${result.billNumber} saved & sent to printer` });
      } else {
        setMessage({
          type: 'warning',
          text: `Bill ${result.billNumber} saved, but print failed: ${printRes.message || 'Unknown'}. You can reprint from Orders.`
        });
      }
      clearCart();
    } catch (e) {
      setMessage({ type: 'error', text: e.message || 'Failed to save order' });
    } finally {
      setLoading(false);
    }
  };

  const handleReprintLast = async () => {
    if (!lastOrder) return;
    setLoading(true);
    try {
      const html = buildReceiptHtml(lastOrder);
      const res = await window.api.printReceipt(html);
      if (res.success) setMessage({ type: 'success', text: 'Reprint sent' });
      else setMessage({ type: 'error', text: res.message || 'Print failed' });
    } catch (e) {
      setMessage({ type: 'error', text: e.message });
    } finally {
      setLoading(false);
    }
  };

  // Group menu by category
  const categories = [...new Set(menu.map((m) => m.category))];

  return (
    <div className="flex h-full overflow-hidden">
      {/* Menu area */}
      <div className="flex-1 overflow-y-auto p-5">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-cream">Menu</h1>
          <button
            onClick={loadMenu}
            className="text-xs text-charcoal-400 hover:text-orange-400 transition-colors"
          >
            Refresh
          </button>
        </div>

        {categories.map((cat) => (
          <div key={cat} className="mb-6">
            <h2 className="text-sm font-semibold text-orange-400 uppercase tracking-wider mb-3">
              {cat}
            </h2>
            <div className="grid grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-3">
              {menu
                .filter((m) => m.category === cat)
                .map((item) => (
                  <MenuItemCard key={`${item.id}-${item.size}`} item={item} onAdd={addToCart} />
                ))}
            </div>
          </div>
        ))}

        {menu.length === 0 && (
          <div className="text-center text-charcoal-400 py-20">
            No menu items. Add some in Settings.
          </div>
        )}
      </div>

      {/* Cart panel */}
      <div className="w-96 flex-shrink-0 bg-charcoal-800 border-l border-charcoal-600 flex flex-col">
        <div className="px-4 py-3 border-b border-charcoal-600">
          <h2 className="font-semibold text-cream">Current Bill</h2>
        </div>

        {/* Order type */}
        <div className="px-4 py-3 flex gap-2 border-b border-charcoal-600">
          {['Dine-in', 'Takeaway'].map((t) => (
            <button
              key={t}
              onClick={() => setOrderType(t)}
              className={`flex-1 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                orderType === t
                  ? 'bg-orange-500 text-white'
                  : 'bg-charcoal-700 text-charcoal-300 hover:bg-charcoal-600'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Customer */}
        <div className="px-4 py-3 space-y-2 border-b border-charcoal-600">
          <input
            type="text"
            placeholder="Customer name (optional)"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg bg-charcoal-700 border border-charcoal-600 text-sm text-white placeholder-charcoal-400 focus:outline-none focus:ring-1 focus:ring-orange-500"
          />
          <input
            type="text"
            placeholder="Phone (optional)"
            value={customerPhone}
            onChange={(e) => setCustomerPhone(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg bg-charcoal-700 border border-charcoal-600 text-sm text-white placeholder-charcoal-400 focus:outline-none focus:ring-1 focus:ring-orange-500"
          />
        </div>

        {/* Cart items */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          {cart.length === 0 && (
            <p className="text-center text-charcoal-400 text-sm py-8">Click menu items to add</p>
          )}
          {cart.map((c) => {
            const key = `${c.id}-${c.size || ''}`;
            return (
              <div
                key={key}
                className="bg-charcoal-700 rounded-lg p-3 flex items-center gap-2"
              >
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-cream truncate">
                    {c.name}
                    {c.size ? ` (${c.size})` : ''}
                  </div>
                  <div className="text-xs text-charcoal-400">{formatPKR(c.price)} each</div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => updateQty(key, -1)}
                    className="w-7 h-7 rounded bg-charcoal-600 hover:bg-charcoal-500 text-white text-sm font-bold"
                  >
                    −
                  </button>
                  <span className="w-7 text-center text-sm font-semibold">{c.qty}</span>
                  <button
                    onClick={() => updateQty(key, 1)}
                    className="w-7 h-7 rounded bg-charcoal-600 hover:bg-charcoal-500 text-white text-sm font-bold"
                  >
                    +
                  </button>
                </div>
                <div className="w-16 text-right text-sm font-semibold text-orange-400">
                  {formatPKR(c.price * c.qty)}
                </div>
                <button
                  onClick={() => removeItem(key)}
                  className="text-red-400 hover:text-red-300 text-sm ml-1"
                  title="Remove"
                >
                  ✕
                </button>
              </div>
            );
          })}
        </div>

        {/* Totals */}
        <div className="px-4 py-3 border-t border-charcoal-600 space-y-2">
          <div className="flex justify-between text-sm text-charcoal-300">
            <span>Subtotal</span>
            <span>{formatPKR(subtotal)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-charcoal-300">Discount (Rs.)</span>
            <input
              type="number"
              min="0"
              max={subtotal}
              value={discount}
              onChange={(e) => setDiscount(e.target.value)}
              className="w-24 px-2 py-1 rounded bg-charcoal-700 border border-charcoal-600 text-right text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
          </div>
          <div className="flex justify-between text-lg font-bold text-cream pt-1">
            <span>Total</span>
            <span className="text-orange-400">{formatPKR(total)}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="px-4 py-3 border-t border-charcoal-600 space-y-2">
          {message && (
            <div
              className={`text-xs px-3 py-2 rounded-lg ${
                message.type === 'success'
                  ? 'bg-green-900/40 text-green-300 border border-green-700'
                  : message.type === 'warning'
                  ? 'bg-yellow-900/40 text-yellow-200 border border-yellow-700'
                  : 'bg-red-900/40 text-red-200 border border-red-700'
              }`}
            >
              {message.text}
            </div>
          )}
          <button
            onClick={handleGenerateBill}
            disabled={loading || cart.length === 0}
            className="w-full py-3 rounded-xl bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white font-bold text-base transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Processing…' : 'Generate Bill & Save'}
          </button>
          <div className="flex gap-2">
            <button
              onClick={clearCart}
              className="flex-1 py-2 rounded-lg bg-charcoal-700 hover:bg-charcoal-600 text-charcoal-300 text-sm"
            >
              Clear
            </button>
            {lastOrder && (
              <button
                onClick={handleReprintLast}
                disabled={loading}
                className="flex-1 py-2 rounded-lg bg-charcoal-700 hover:bg-charcoal-600 text-charcoal-300 text-sm"
              >
                Reprint Last
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
