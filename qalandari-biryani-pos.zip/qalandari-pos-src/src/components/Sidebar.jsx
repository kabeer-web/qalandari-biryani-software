import React from 'react';

const navItems = [
  { id: 'pos', label: 'POS / Takeaway', icon: '🧾' },
  { id: 'orders', label: 'Orders & Records', icon: '📋' },
  { id: 'settings', label: 'Settings', icon: '⚙️' }
];

export default function Sidebar({ current, onNavigate, onLogout }) {
  return (
    <aside className="w-56 flex-shrink-0 bg-charcoal-800 border-r border-charcoal-600 flex flex-col h-full">
      {/* Brand */}
      <div className="px-4 py-5 border-b border-charcoal-600">
        <div className="text-orange-400 font-bold text-lg leading-tight">Qalandari</div>
        <div className="text-cream text-xs font-medium">Biryani Food Center</div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              current === item.id
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                : 'text-charcoal-300 hover:bg-charcoal-700 hover:text-white'
            }`}
          >
            <span className="text-base">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="px-3 py-4 border-t border-charcoal-600 space-y-2">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-400 hover:bg-red-900/30 transition-colors"
        >
          <span>🚪</span> Logout
        </button>
        <p className="text-[10px] text-charcoal-500 text-center px-2">
          Powered by BeerFlow Technologies
        </p>
      </div>
    </aside>
  );
}
