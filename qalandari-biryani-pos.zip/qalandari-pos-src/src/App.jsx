import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import POS from './components/POS';
import Orders from './components/Orders';
import Settings from './components/Settings';

function MainApp() {
  const { isAuthenticated, logout } = useAuth();
  const [page, setPage] = useState('pos');

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <div className="flex h-screen bg-charcoal-800">
      <Sidebar current={page} onNavigate={setPage} onLogout={logout} />
      <main className="flex-1 overflow-hidden bg-charcoal-900">
        {page === 'pos' && <POS />}
        {page === 'orders' && <Orders />}
        {page === 'settings' && <Settings />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
