import { formatPKR, formatDateTime } from './format';

export function buildReceiptHtml(order) {
  const itemsHtml = (order.items || [])
    .map(
      (it) => `
      <tr>
        <td style="padding:4px 0;text-align:left;">${escapeHtml(it.name)}${it.size ? ` (${it.size})` : ''}</td>
        <td style="padding:4px 0;text-align:center;">${it.quantity || it.qty}</td>
        <td style="padding:4px 0;text-align:right;">${formatPKR(it.price)}</td>
        <td style="padding:4px 0;text-align:right;">${formatPKR(it.line_total || it.price * (it.quantity || it.qty))}</td>
      </tr>`
    )
    .join('');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      font-size: 12px;
      color: #111;
      width: 280px;
      padding: 12px;
      background: #fff;
    }
    .center { text-align: center; }
    .bold { font-weight: 700; }
    .title { font-size: 16px; font-weight: 800; letter-spacing: 0.5px; }
    .subtitle { font-size: 11px; color: #444; margin-top: 2px; }
    .divider { border-top: 1px dashed #999; margin: 8px 0; }
    table { width: 100%; border-collapse: collapse; }
    th { font-size: 10px; text-transform: uppercase; color: #555; padding-bottom: 4px; border-bottom: 1px solid #ddd; }
    .total-row td { font-weight: 700; font-size: 13px; padding-top: 6px; }
    .footer { margin-top: 12px; font-size: 10px; color: #666; text-align: center; }
    .brand { margin-top: 6px; font-size: 9px; color: #999; }
  </style>
</head>
<body>
  <div class="center">
    <div class="title">Qalandari Biryani</div>
    <div class="subtitle">Food Center</div>
  </div>
  <div class="divider"></div>
  <div>
    <div><span class="bold">Bill #:</span> ${escapeHtml(order.bill_number || order.billNumber)}</div>
    <div><span class="bold">Date:</span> ${formatDateTime(order.created_at || new Date().toISOString())}</div>
    <div><span class="bold">Type:</span> ${escapeHtml(order.order_type || order.orderType)}</div>
    ${order.customer_name || order.customerName ? `<div><span class="bold">Customer:</span> ${escapeHtml(order.customer_name || order.customerName)}</div>` : ''}
    ${order.customer_phone || order.customerPhone ? `<div><span class="bold">Phone:</span> ${escapeHtml(order.customer_phone || order.customerPhone)}</div>` : ''}
  </div>
  <div class="divider"></div>
  <table>
    <thead>
      <tr>
        <th style="text-align:left;">Item</th>
        <th style="text-align:center;">Qty</th>
        <th style="text-align:right;">Price</th>
        <th style="text-align:right;">Total</th>
      </tr>
    </thead>
    <tbody>
      ${itemsHtml}
    </tbody>
  </table>
  <div class="divider"></div>
  <table>
    <tr>
      <td>Subtotal</td>
      <td style="text-align:right;">${formatPKR(order.subtotal)}</td>
    </tr>
    ${(order.discount || 0) > 0 ? `
    <tr>
      <td>Discount</td>
      <td style="text-align:right;">- ${formatPKR(order.discount)}</td>
    </tr>` : ''}
    <tr class="total-row">
      <td>TOTAL</td>
      <td style="text-align:right;">${formatPKR(order.total)}</td>
    </tr>
  </table>
  <div class="divider"></div>
  <div class="footer">
    Thank you for dining with us!<br/>
    Please visit again.
    <div class="brand">Powered by BeerFlow Technologies</div>
  </div>
</body>
</html>`;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
