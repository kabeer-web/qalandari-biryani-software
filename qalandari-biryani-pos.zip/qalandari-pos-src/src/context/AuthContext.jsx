import React, { createContext, useContext, useState, useCallback } from 'react';

const AuthContext = createContext(null);

function getApi() {
  if (typeof window !== 'undefined' && window.api) return window.api;
  return null;
}

export function AuthProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const login = useCallback(async (username, password) => {
    setLoading(true);
    setError('');
    try {
      const api = getApi();
      if (!api) {
        setError(
          'App API not available. Please close this window and run: npm run dev (must open Electron window, not browser).'
        );
        return false;
      }
      const res = await api.login({ username, password });
      if (res.success) {
        setIsAuthenticated(true);
        return true;
      }
      setError(res.message || 'Login failed');
      return false;
    } catch (e) {
      setError(e.message || 'Login error');
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    setIsAuthenticated(false);
  }, []);

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout, loading, error, setError }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
