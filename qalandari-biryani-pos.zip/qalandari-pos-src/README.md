# Qalandari Biryani Food Center — Desktop POS

**Powered by BeerFlow Technologies**

Offline Windows Point-of-Sale application for Qalandari Biryani Food Center.

## Features

- Modern dark UI (orange / cream / charcoal)
- Local admin login (password hashed with bcrypt)
- Fast POS / Takeaway billing
- Editable menu with prices
- Automatic receipt generation + print (A4 / thermal)
- Daily orders, search, date filter, CSV export
- SQLite local database (persists across restarts)
- Database backup & restore
- Fully offline — no cloud required

## Default Login

| Field    | Value     |
|----------|-----------|
| Username | `admin`   |
| Password | `admin123`|

Change these immediately in **Settings → Account**.

## Requirements

- Node.js 18 or newer (LTS recommended)
- Windows 10/11 (for the final `.exe`)

## Development

```bash
# 1. Install dependencies (first time only)
npm install

# 2. Run in development mode (starts Vite + Electron together)
npm run dev
```

**Important:** Login only works inside the **Electron window** titled "Qalandari Biryani POS".
Do NOT open `http://localhost:5173` in Chrome/Edge — `window.api` only exists in Electron.

If you see `Cannot read properties of undefined (reading 'login')`:
1. Close all windows
2. Stop the terminal (`Ctrl+C`)
3. Run `npm run dev` again
4. Use the Electron app window that opens automatically (not the browser tab)

## Build Windows Installer

```bash
npm run electron:build
```

The installer will be created in:

```
dist-installer/Qalandari Biryani POS Setup x.x.x.exe
```

- NSIS installer
- User can choose install location
- Desktop + Start Menu shortcuts
- Uninstall via Windows Settings

## Project Structure

```
electron/          Main process, SQLite, IPC (preload.cjs)
src/               React UI
  components/      POS, Orders, Settings, Login, Sidebar
  context/         Auth
  utils/           Formatting + receipt HTML
public/            Icons
```

## Notes

- Database is stored in Electron `userData` folder (survives updates).
- Printer errors are reported; bills are never silently marked as printed.
- Menu prices updated in Settings are used for all future orders.
- No internet connection is required after installation.

---

© BeerFlow Technologies
